#!/usr/bin/env bash
set -euo pipefail

EXPECTED_HEAD="74d59b964052c416391531549e9139d87facf00a"
ZIP_PATH="${1:-}"

if [[ -z "$ZIP_PATH" || ! -f "$ZIP_PATH" ]]; then
  echo "Błąd: nie przekazano prawidłowej paczki ZIP."
  exit 1
fi

ROOT=""
for candidate in "$PWD" /workspace /workspaces/*; do
  if [[ -d "$candidate/.git" && -f "$candidate/frontend/pubspec.yaml" ]]; then
    ROOT="$(cd "$candidate" && pwd)"
    break
  fi
done
if [[ -z "$ROOT" ]]; then
  echo "Błąd: nie znaleziono repozytorium mealplanner1108."
  exit 1
fi

cd "$ROOT"
echo "Repozytorium: $ROOT"
echo "Paczka: $ZIP_PATH"

if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo "Zatrzymano: repozytorium zawiera lokalne zmiany w śledzonych plikach."
  git status --short --untracked-files=no
  exit 1
fi

git fetch origin main
git merge --ff-only origin/main
CURRENT_HEAD="$(git rev-parse HEAD)"
if [[ "$CURRENT_HEAD" != "$EXPECTED_HEAD" ]]; then
  echo "Zatrzymano bez kopiowania: oczekiwano $EXPECTED_HEAD, a jest $CURRENT_HEAD."
  exit 1
fi

TEMP_DIR="$(mktemp -d)"
trap 'rm -rf -- "$TEMP_DIR"' EXIT
unzip -q "$ZIP_PATH" 'payload/*' 'files.txt' -d "$TEMP_DIR"
cp -a "$TEMP_DIR/payload/." "$ROOT/"

git diff --check

# Paczka jest celowo mała. Przed testami upewniamy się, że zmieniła wyłącznie
# trzy zadeklarowane pliki, zamiast ponownie nadpisywać całą aplikację.
while IFS= read -r file; do
  [[ -z "$file" ]] && continue
  if ! grep -Fqx -- "$file" "$TEMP_DIR/files.txt"; then
    echo "Zatrzymano: nieoczekiwana zmiana pliku $file."
    exit 1
  fi
done < <(git diff --name-only)

python -m pytest backend/tests -q

cd "$ROOT/frontend"
flutter pub get
flutter analyze --no-fatal-infos --no-fatal-warnings
flutter test
flutter build appbundle --release
cp build/app/outputs/bundle/release/app-release.aab \
  "$ROOT/mealplanner-1.0.35-232.aab"

cd "$ROOT"
while IFS= read -r file; do
  [[ -z "$file" ]] && continue
  if ! grep -Fqx -- "$file" "$TEMP_DIR/files.txt"; then
    echo "Zatrzymano przed commitem: narzędzia zmieniły dodatkowy plik $file."
    exit 1
  fi
done < <(git diff --name-only)

while IFS= read -r file; do
  [[ -n "$file" ]] && git add -- "$file"
done < "$TEMP_DIR/files.txt"

git commit -m "Popraw dolny przycisk i opcje dodawania przepisu 1.0.35+232"
git push origin main

echo
echo "Gotowe. AAB: $ROOT/mealplanner-1.0.35-232.aab"
echo "Na GitHub wysłano wyłącznie trzy pliki tej poprawki."
