#!/usr/bin/env bash
set -euo pipefail

ZIP_PATH="${1:-}"
EXPECTED_SHA="bfac9b575148147ef0b67a3f067877d4126e64a8"

if [[ -z "$ZIP_PATH" || ! -f "$ZIP_PATH" ]]; then
  echo "Nie znaleziono paczki ZIP: $ZIP_PATH"
  exit 1
fi

REPO=""
for CANDIDATE in "$PWD" /workspace /workspaces/*; do
  if [[ -d "$CANDIDATE/.git" && -f "$CANDIDATE/frontend/pubspec.yaml" ]]; then
    REPO="$CANDIDATE"
    break
  fi
done

if [[ -z "$REPO" ]]; then
  echo "Nie znaleziono repozytorium mealplanner1108."
  exit 1
fi

cd "$REPO"
echo "Repozytorium: $REPO"
echo "Paczka: $ZIP_PATH"
git fetch origin main

LOCAL_SHA="$(git rev-parse HEAD)"
REMOTE_SHA="$(git rev-parse origin/main)"
if [[ "$LOCAL_SHA" != "$EXPECTED_SHA" || "$REMOTE_SHA" != "$EXPECTED_SHA" ]]; then
  echo "Zatrzymano bez kopiowania: paczka oczekuje main $EXPECTED_SHA."
  echo "Lokalnie: $LOCAL_SHA; GitHub: $REMOTE_SHA."
  exit 1
fi

if [[ -n "$(git status --porcelain --untracked-files=no)" ]]; then
  echo "Zatrzymano: repozytorium ma niezapisane zmiany w śledzonych plikach."
  git status --short
  exit 1
fi

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
unzip -q "$ZIP_PATH" -d "$TMP_DIR"

mapfile -t FILES < "$TMP_DIR/manifest.txt"
for FILE in "${FILES[@]}"; do
  [[ -n "$FILE" ]] || continue
  if [[ ! -f "$TMP_DIR/$FILE" ]]; then
    echo "Brak pliku w paczce: $FILE"
    exit 1
  fi
  mkdir -p "$(dirname "$REPO/$FILE")"
  cp "$TMP_DIR/$FILE" "$REPO/$FILE"
done

export ENVIRONMENT=development
cd "$REPO/backend"
python -m pytest -q tests

cd "$REPO/frontend"
flutter pub get
mapfile -t DART_FILES < <(printf '%s\n' "${FILES[@]}" | sed -n 's#^frontend/\(.*\.dart\)$#\1#p')
if (( ${#DART_FILES[@]} > 0 )); then
  dart format "${DART_FILES[@]}"
fi
flutter analyze --no-fatal-infos --no-fatal-warnings
flutter test
flutter build appbundle --release

cd "$REPO"
git diff --check
git add -- "${FILES[@]}"
git commit -m "Audyt UI/UX i skanowanie seryjne 1.0.37+234"
git push origin main

echo "Gotowe. AAB: $REPO/frontend/build/app/outputs/bundle/release/app-release.aab"
