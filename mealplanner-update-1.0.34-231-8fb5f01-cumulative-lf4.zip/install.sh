#!/usr/bin/env bash
set -euo pipefail

EXPECTED_HEAD="8fb5f01bb971229e90a5659bed0142a5ff3c09ec"
ZIP_PATH="${1:-}"

if [[ -z "$ZIP_PATH" || ! -f "$ZIP_PATH" ]]; then
  echo "Błąd: podaj ścieżkę do paczki ZIP jako pierwszy argument."
  exit 1
fi

ROOT=""
for candidate in "$PWD" /workspace /workspaces/*; do
  if [[ -d "$candidate/.git" && -f "$candidate/frontend/pubspec.yaml" ]]; then
    ROOT="$(cd "$candidate" && pwd)"
    break
  fi
done
if [[ -z "$ROOT" ]]; then
  echo "Błąd: nie znaleziono repozytorium mealplanner1108."
  exit 1
fi

cd "$ROOT"
echo "Repozytorium: $ROOT"
echo "Paczka: $ZIP_PATH"

git fetch origin main
CURRENT_HEAD="$(git rev-parse HEAD)"
REMOTE_HEAD="$(git rev-parse origin/main)"
if [[ "$CURRENT_HEAD" != "$EXPECTED_HEAD" || "$REMOTE_HEAD" != "$EXPECTED_HEAD" ]]; then
  echo "Zatrzymano bez kopiowania: paczka oczekuje main $EXPECTED_HEAD."
  echo "Lokalnie: $CURRENT_HEAD; GitHub: $REMOTE_HEAD."
  exit 1
fi

if ! git diff --cached --quiet; then
  echo "Zatrzymano: w repozytorium są już pliki dodane do commita."
  exit 1
fi

TEMP_DIR="$(mktemp -d)"
trap 'rm -rf -- "$TEMP_DIR"' EXIT
unzip -q "$ZIP_PATH" 'payload/*' 'files.txt' 'preflight.sha256' -d "$TEMP_DIR"

# Poprzednia paczka mogła pozostawić wyłącznie swoje pliki z końcami CRLF.
# Każdy taki plik sprawdzamy po SHA-256, zanim zastąpimy go wersją LF.
verify_previous_payload_file() {
  local file="$1"
  local expected_hash actual_hash
  if [[ "$file" == "frontend/pubspec.lock" ]]; then
    echo "Pozwalam odtworzyć frontend/pubspec.lock (plik generowany przez Fluttera)."
    return
  fi
  expected_hash="$(awk -v target="$file" '$2 == target { print $1; exit }' "$TEMP_DIR/preflight.sha256")"
  actual_hash="$(sha256sum -- "$file" | awk '{ print $1 }')"
  if [[ -z "$expected_hash" || "$actual_hash" != "$expected_hash" ]]; then
    echo "Zatrzymano: plik $file zawiera zmianę inną niż pozostawiona przez poprzednią paczkę."
    exit 1
  fi
}

while IFS= read -r file; do
  [[ -z "$file" ]] && continue
  if ! grep -Fqx -- "$file" "$TEMP_DIR/files.txt"; then
    echo "Zatrzymano: wykryto lokalną zmianę spoza paczki: $file"
    exit 1
  fi
  verify_previous_payload_file "$file"
done < <(git diff --name-only)

# Sprawdzamy również nowe pliki kodu utworzone przez poprzednią paczkę.
# Inne nieśledzone pliki w /workspace, np. archiwa ZIP, pozostają nietknięte.
while IFS= read -r file; do
  [[ -z "$file" || ! -f "$file" ]] && continue
  if ! git ls-files --error-unmatch -- "$file" >/dev/null 2>&1; then
    verify_previous_payload_file "$file"
  fi
done < "$TEMP_DIR/files.txt"

cp -a "$TEMP_DIR/payload/." "$ROOT/"
echo "Wgrano 150 plików z prawidłowymi końcami LF (wersja 1.0.34+231)."

git diff --check
python -m pytest backend/tests -q

cd "$ROOT/frontend"
flutter pub get
flutter analyze --no-fatal-infos --no-fatal-warnings
flutter test
flutter build appbundle --release
cp build/app/outputs/bundle/release/app-release.aab \
  "$ROOT/mealplanner-1.0.34-231.aab"

cd "$ROOT"
while IFS= read -r file; do
  [[ -n "$file" ]] && git add -- "$file"
done < "$TEMP_DIR/files.txt"

if git diff --cached --quiet; then
  echo "Brak nowych zmian — zawartość paczki jest już w repozytorium."
else
  git commit -m "Zbiorcza aktualizacja skanera, kampanii i interfejsu 1.0.34+231"
  git push origin main
fi

echo
echo "Gotowe. AAB: $ROOT/mealplanner-1.0.34-231.aab"
echo "Push na main uruchomi Render i Xcode Cloud, jeśli automatyczne wdrożenia są aktywne."
