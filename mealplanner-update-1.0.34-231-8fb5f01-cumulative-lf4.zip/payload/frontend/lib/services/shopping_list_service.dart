import '../models/shopping_list.dart';
import 'api_client.dart';
import '../config/api_config.dart';

/// Zaproszenie/udostępnienie listy zakupów — dwuetapowe (pending ->
/// accepted). Jedna klasa obsługuje oba kierunki (kto komu udostępnił),
/// pola shared_by_name/shared_with_name są opcjonalne w zależności od
/// kontekstu (patrz backend, ShoppingListShareResponse).
class ShoppingListShare {
  final String id;
  final String mealPlanId;
  final String status;
  final DateTime createdAt;
  final String? sharedByName;
  final String? sharedWithName;
  final String? sharedWithEmail;

  ShoppingListShare({
    required this.id,
    required this.mealPlanId,
    required this.status,
    required this.createdAt,
    this.sharedByName,
    this.sharedWithName,
    this.sharedWithEmail,
  });

  factory ShoppingListShare.fromJson(Map<String, dynamic> json) {
    return ShoppingListShare(
      id: json['id'] as String,
      mealPlanId: json['meal_plan_id'] as String,
      status: json['status'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      sharedByName: json['shared_by_name'] as String?,
      sharedWithName: json['shared_with_name'] as String?,
      sharedWithEmail: json['shared_with_email'] as String?,
    );
  }
}

class ShoppingListService {
  final ApiClient _client = ApiClient();

  Future<ShoppingList> getShoppingList(String listId) async {
    final response = await _client.get('${ApiConfig.shoppingLists}$listId');
    return ShoppingList.fromJson(response as Map<String, dynamic>);
  }

  /// Twoje zarządzalne listy zakupów (utworzone z wybranych przepisów) —
  /// te, do których można dopisywać kolejne przepisy.
  Future<List<ShoppingList>> getMyLists() async {
    final response = await _client.get('${ApiConfig.shoppingLists}mine');
    return (response as List)
        .map((e) => ShoppingList.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  /// Usuwa listę zakupów; tygodniowy limit utworzeń pozostaje zużyty.
  Future<void> deleteList(String listId) async {
    await _client.delete('${ApiConfig.shoppingLists}$listId');
  }

  Future<void> toggleItemCheck(String listId, String itemId) async {
    await _client.put('${ApiConfig.shoppingLists}$listId/items/$itemId/check');
  }

  /// Dopisuje pojedynczy produkt (spoza przepisu) do listy.
  Future<void> addProduct(
    String listId,
    String productId, {
    double quantity = 1.0,
    String unit = 'szt',
  }) async {
    await _client.post(
      '${ApiConfig.shoppingLists}$listId/items',
      body: {'product_id': productId, 'quantity': quantity, 'unit': unit},
    );
  }

  /// Dopisuje pozycję spoza katalogu, np. chemię domową lub baterie.
  Future<void> addCustomItem(
    String listId,
    String name, {
    double quantity = 1.0,
    String unit = 'szt',
  }) async {
    await _client.post(
      '${ApiConfig.shoppingLists}$listId/items/custom',
      body: {'name': name, 'quantity': quantity, 'unit': unit},
    );
  }

  /// Tworzy pustą listę, aby użytkownik mógł rozpocząć zakupy od
  /// przycisku „+”, bez wcześniejszego układania planu posiłków.
  Future<ShoppingList> createEmptyList(String storeId) async {
    final response = await _client.post(
      '${ApiConfig.shoppingLists}empty',
      body: {'store_id': storeId},
    );
    return ShoppingList.fromJson(response as Map<String, dynamic>);
  }

  /// Łączy co najmniej dwie własne listy z tego samego sklepu.
  Future<ShoppingList> mergeLists(List<String> listIds) async {
    final response = await _client.post(
      '${ApiConfig.shoppingLists}merge',
      body: {'list_ids': listIds},
    );
    return ShoppingList.fromJson(response as Map<String, dynamic>);
  }

  /// Kończy listę; `moveToPantry` przenosi odhaczone produkty do spiżarni.
  Future<int> completeList(String listId, {bool moveToPantry = true}) async {
    final response = await _client.post(
      '${ApiConfig.shoppingLists}$listId/complete?move_to_pantry=$moveToPantry',
    );
    if (response is Map<String, dynamic>) {
      return (response['moved_to_pantry'] as int?) ?? 0;
    }
    return 0;
  }

  Future<void> deleteItem(String listId, String itemId) async {
    await _client.delete('${ApiConfig.shoppingLists}$listId/items/$itemId');
  }

  Future<void> substituteItem(String listId, String itemId, String substituteProductId) async {
    await _client.put(
      '${ApiConfig.shoppingLists}$listId/items/$itemId/substitute',
      body: {'substitute_product_id': substituteProductId},
    );
  }

  Future<Map<String, dynamic>> getSummary(String listId) async {
    final response = await _client.get('${ApiConfig.shoppingLists}$listId/summary');
    return response as Map<String, dynamic>;
  }

  /// Tworzy NOWĄ listę zakupów na konkretne danie/dania (podlega
  /// limitowi jednej nowej listy tygodniowo dla konta standardowego) — ALBO, jeśli podano
  /// [existingListId], dopisuje przepisy do JUŻ ISTNIEJĄCEJ listy (nie
  /// zużywa limitu).
  Future<ShoppingList> createFromRecipes({
    required List<String> recipeIds,
    required String storeId,
    String? existingListId,
  }) async {
    final body = <String, dynamic>{'recipe_ids': recipeIds, 'store_id': storeId};
    if (existingListId != null) body['existing_list_id'] = existingListId;
    final response = await _client.post(
      '${ApiConfig.shoppingLists}from-recipes',
      body: body,
    );
    return ShoppingList.fromJson(response as Map<String, dynamic>);
  }

  /// Udostępnia listę zakupów innemu użytkownikowi po adresie e-mail —
  /// tworzy ZAPROSZENIE (status "pending"), druga strona musi je
  /// zaakceptować, zanim dostanie faktyczny dostęp do listy.
  /// Udostępnia listę po NAZWIE UŻYTKOWNIKA (nie po e-mailu) — nazwy są
  /// unikalne, więc wskazanie jest jednoznaczne.
  Future<ShoppingListShare> shareList(String listId, String displayName) async {
    final response = await _client.post(
      '${ApiConfig.shoppingLists}$listId/share',
      body: {'display_name': displayName},
    );
    return ShoppingListShare.fromJson(response as Map<String, dynamic>);
  }

  /// Zaproszenia oczekujące NA CIEBIE (do zaakceptowania/odrzucenia).
  Future<List<ShoppingListShare>> getPendingShares() async {
    final response = await _client.get('${ApiConfig.shoppingLists}shares/pending');
    return (response as List).map((e) => ShoppingListShare.fromJson(e as Map<String, dynamic>)).toList();
  }

  /// Listy, które ktoś Ci udostępnił i które już zaakceptowałeś.
  Future<List<ShoppingListShare>> getSharedWithMe() async {
    final response = await _client.get('${ApiConfig.shoppingLists}shares/shared-with-me');
    return (response as List).map((e) => ShoppingListShare.fromJson(e as Map<String, dynamic>)).toList();
  }

  Future<ShoppingListShare> acceptShare(String shareId) async {
    final response = await _client.post('${ApiConfig.shoppingLists}shares/$shareId/accept');
    return ShoppingListShare.fromJson(response as Map<String, dynamic>);
  }

  /// Odrzuca zaproszenie / usuwa udostępnienie / opuszcza współdzieloną
  /// listę — to ten sam endpoint dla wszystkich trzech przypadków
  /// (patrz komentarz w backendzie).
  Future<void> deleteShare(String shareId) async {
    await _client.delete('${ApiConfig.shoppingLists}shares/$shareId');
  }
}
