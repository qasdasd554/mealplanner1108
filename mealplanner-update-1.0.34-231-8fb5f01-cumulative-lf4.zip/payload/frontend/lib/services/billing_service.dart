import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:in_app_purchase_android/in_app_purchase_android.dart';
import '../config/api_config.dart';
import 'api_client.dart';

/// Bezpieczne (też na web) wykrycie platformy — w przeciwieństwie do
/// Platform.isIOS z dart:io, defaultTargetPlatform nie wywala kompilacji
/// na web. Backend rozróżnia po tym polu, którego sklepu (Google/Apple)
/// użyć do weryfikacji zakupu.
String get _currentStorePlatform =>
    defaultTargetPlatform == TargetPlatform.iOS ? 'ios' : 'android';

/// ID produktów subskrypcyjnych — MUSZĄ dokładnie odpowiadać temu, co
/// zostało utworzone w Google Play Console (patrz przewodnik konfiguracji
/// płatności). Zmiana tych stringów bez zmiany w Play Console spowoduje,
/// że aplikacja nie znajdzie żadnych produktów do kupienia.
const String kWeeklyProductId = 'premium_weekly_v2';
const String kMonthlyProductId = 'premium_monthly';
const String kYearlyProductId = 'premium_yearly';

/// ID pakietów punktów premium — KONSUMOWALNE produkty (inne niż
/// subskrypcje powyżej), 2 punkty = jedno zapytanie do AI. Ceny
/// ustawione w Google Play Console: 10 pkt/10zł, 20 pkt/17zł, 50 pkt/40zł.
const String kPoints10ProductId = 'points_10';
const String kPoints20ProductId = 'points_20';
const String kPoints50ProductId = 'points_50';

/// Obsługuje cały przepływ zakupu subskrypcji: odpytanie sklepu o
/// dostępne produkty (i ich prawdziwe, lokalne ceny), zainicjowanie
/// zakupu, nasłuchiwanie na wynik, i weryfikację po stronie backendu —
/// to backend, po zapytaniu Google, ostatecznie decyduje, czy nadać
/// dostęp premium (nigdy nie ufamy samej aplikacji, że "zakup się udał").
class BillingService {
  final InAppPurchase _iap = InAppPurchase.instance;
  final ApiClient _client = ApiClient();
  StreamSubscription<List<PurchaseDetails>>? _subscription;

  /// Sprawdza, czy usługa płatności jest w ogóle dostępna na tym
  /// urządzeniu (np. brak konta Google Play, urządzenie bez usług
  /// Google itp. — rzadkie, ale możliwe).
  Future<bool> isAvailable() => _iap.isAvailable();

  /// Pobiera prawdziwe, lokalne ceny (uwzględniające walutę i podatki
  /// danego kraju) dla obu planów subskrypcji.
  Future<ProductDetailsResponse> queryProducts() {
    return _iap.queryProductDetails({kWeeklyProductId, kMonthlyProductId, kYearlyProductId});
  }

  /// Rozpoczyna zakup — wynik przyjdzie asynchronicznie przez
  /// [purchaseStream], nie przez zwróconą wartość tej metody.
  Future<void> buy(ProductDetails product) {
    final purchaseParam = product is GooglePlayProductDetails
        ? GooglePlayPurchaseParam(
            productDetails: product,
            offerToken: product.offerToken,
          )
        : PurchaseParam(productDetails: product);
    // Subskrypcje w ujednoliconym API in_app_purchase obsługuje się przez
    // buyNonConsumable (mimo nazwy — to standardowa ścieżka dla
    // subskrypcji na Androidzie, konsumpcja nie ma tu zastosowania).
    return _iap.buyNonConsumable(purchaseParam: purchaseParam);
  }

  /// Zwraca dokładnie tę ofertę subskrypcji Google Play, którą administrator
  /// powiązał z kampanią. Google generuje `offerToken` osobno dla urządzenia,
  /// dlatego w bazie zapisujemy stabilne offerId/basePlanId, a token wybieramy
  /// dopiero z aktualnej odpowiedzi sklepu.
  ProductDetails? selectAndroidSubscriptionOffer(
    Iterable<ProductDetails> products, {
    required String productId,
    required String basePlanId,
    required String offerId,
  }) {
    for (final product in products) {
      if (product.id != productId || product is! GooglePlayProductDetails) continue;
      final index = product.subscriptionIndex;
      final offers = product.productDetails.subscriptionOfferDetails;
      if (index == null || offers == null || index >= offers.length) continue;
      final details = offers[index];
      if (details.basePlanId == basePlanId && details.offerId == offerId) {
        return product;
      }
    }
    return null;
  }

  /// Wariant bez kampanii: wybiera regularny plan (offerId == null), a gdy
  /// sklep zwróci starszą konfigurację — pierwszy dostępny wariant produktu.
  ProductDetails? selectRegularSubscriptionOffer(
    Iterable<ProductDetails> products,
    String productId,
  ) {
    ProductDetails? fallback;
    for (final product in products) {
      if (product.id != productId) continue;
      fallback ??= product;
      if (product is! GooglePlayProductDetails) return product;
      final index = product.subscriptionIndex;
      final offers = product.productDetails.subscriptionOfferDetails;
      if (index != null && offers != null && index < offers.length &&
          offers[index].offerId == null) {
        return product;
      }
    }
    return fallback;
  }

  /// Przywraca wcześniej kupione, wciąż aktywne subskrypcje — potrzebne
  /// np. po reinstalacji aplikacji albo zmianie urządzenia.
  Future<void> restorePurchases() => _iap.restorePurchases();

  /// Strumień aktualizacji zakupów — nasłuchuj na to, żeby wiedzieć, kiedy
  /// zakup się powiódł/nie powiódł/oczekuje.
  Stream<List<PurchaseDetails>> get purchaseStream => _iap.purchaseStream;

  /// WYMAGANE po każdym udanym (albo przywróconym) zakupie — potwierdza
  /// odbiór wobec sklepu. Bez tego Google automatycznie zwróci pieniądze
  /// użytkownikowi po 3 dniach, traktując zakup jako "nieobsłużony".
  Future<void> completePurchase(PurchaseDetails purchase) {
    return _iap.completePurchase(purchase);
  }

  void dispose() {
    _subscription?.cancel();
  }

  /// Wysyła token zakupu do backendu, który weryfikuje go bezpośrednio u
  /// Google i, jeśli prawdziwy i aktywny, nadaje dostęp premium. Zwraca
  /// zaktualizowane dane premium użytkownika.
  Future<Map<String, dynamic>> verifyPurchase({
    required String purchaseToken,
    required String productId,
  }) async {
    final response = await _client.post(
      ApiConfig.billingVerify,
      body: {'purchase_token': purchaseToken, 'product_id': productId, 'platform': _currentStorePlatform},
    );
    return response as Map<String, dynamic>;
  }

  /// Jak [verifyPurchase], ale przez endpoint /restore — funkcjonalnie
  /// identyczne, osobna ścieżka głównie dla czytelności logów/metryk
  /// po stronie backendu.
  Future<Map<String, dynamic>> restoreOnBackend({
    required String purchaseToken,
    required String productId,
  }) async {
    final response = await _client.post(
      ApiConfig.billingRestore,
      body: {'purchase_token': purchaseToken, 'product_id': productId, 'platform': _currentStorePlatform},
    );
    return response as Map<String, dynamic>;
  }

  /// Pobiera prawdziwe, lokalne ceny pakietów punktów premium.
  Future<ProductDetailsResponse> queryPointsProducts() {
    return _iap.queryProductDetails({kPoints10ProductId, kPoints20ProductId, kPoints50ProductId});
  }

  /// Rozpoczyna zakup pakietu punktów — KONSUMOWALNY zakup
  /// (buyConsumable, nie buyNonConsumable jak subskrypcja), bo to
  /// produkt jednorazowy, który można kupić WIELOKROTNIE (w
  /// przeciwieństwie do subskrypcji, którą się "ma" albo "nie ma").
  Future<void> buyPoints(ProductDetails product) {
    final purchaseParam = PurchaseParam(productDetails: product);
    return _iap.buyConsumable(purchaseParam: purchaseParam);
  }

  /// Wysyła token zakupu punktów do backendu, który weryfikuje go u
  /// Google i dolicza punkty do konta. Zwraca nowe saldo.
  Future<int> verifyPointsPurchase({
    required String purchaseToken,
    required String productId,
  }) async {
    final response = await _client.post(
      ApiConfig.billingVerifyPoints,
      body: {'purchase_token': purchaseToken, 'product_id': productId, 'platform': _currentStorePlatform},
    );
    return (response as Map<String, dynamic>)['premium_points'] as int;
  }
}
