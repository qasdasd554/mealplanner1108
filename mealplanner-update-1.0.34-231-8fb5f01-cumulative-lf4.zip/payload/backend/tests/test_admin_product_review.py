"""Regresja: decyzja administratora nie może zależeć od opcjonalnego sklepu."""

import asyncio
import uuid
from decimal import Decimal
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

from app.api.v1.products import review_product, router as products_router


def test_pending_route_precedes_generic_product_route() -> None:
    get_paths = [route.path for route in products_router.routes if "GET" in route.methods]
    assert get_paths.index("/admin/pending") < get_paths.index("/{product_id}")


def _pending_product():
    return SimpleNamespace(
        id=uuid.uuid4(), review_status="pending",
        requested_store_ids=None, submitted_price=None,
        created_by_user_id=None, name="Produkt testowy",
    )


def test_admin_can_approve_product_without_store_or_price() -> None:
    product = _pending_product()
    db = SimpleNamespace(get=AsyncMock(return_value=product),
                         add=MagicMock(), commit=AsyncMock())
    asyncio.run(review_product(
        product.id, approve=True, db=db,
        current_user=SimpleNamespace(role="admin"),
    ))
    assert product.review_status == "approved"
    db.commit.assert_awaited_once()


def test_admin_can_correct_previous_rejection() -> None:
    product = _pending_product()
    product.review_status = "rejected"
    db = SimpleNamespace(get=AsyncMock(return_value=product),
                         add=MagicMock(), commit=AsyncMock())
    asyncio.run(review_product(
        product.id, approve=True, db=db,
        current_user=SimpleNamespace(role="admin"),
    ))
    assert product.review_status == "approved"
    db.commit.assert_awaited_once()


def test_store_error_does_not_undo_approval() -> None:
    product = _pending_product()
    product.requested_store_ids = [str(uuid.uuid4())]
    product.submitted_price = Decimal("5.00")
    nested = MagicMock()
    nested.__aenter__ = AsyncMock()
    nested.__aexit__ = AsyncMock(return_value=False)
    db = SimpleNamespace(
        get=AsyncMock(side_effect=[product, RuntimeError("store lookup failed")]),
        add=MagicMock(),
        commit=AsyncMock(),
        begin_nested=MagicMock(return_value=nested),
    )
    asyncio.run(review_product(
        product.id, approve=True, db=db,
        current_user=SimpleNamespace(role="admin"),
    ))
    assert product.review_status == "approved"
    assert db.commit.await_count == 2


def test_approval_adds_store_product_once() -> None:
    product = _pending_product()
    product.requested_store_ids = [str(uuid.uuid4())]
    product.submitted_price = Decimal("5.00")
    nested = MagicMock()
    nested.__aenter__ = AsyncMock()
    nested.__aexit__ = AsyncMock(return_value=False)
    existing_result = MagicMock()
    existing_result.scalar_one_or_none.return_value = None
    db = SimpleNamespace(
        get=AsyncMock(side_effect=[product, SimpleNamespace(id=uuid.uuid4())]),
        execute=AsyncMock(return_value=existing_result),
        add=MagicMock(), flush=AsyncMock(), commit=AsyncMock(),
        begin_nested=MagicMock(return_value=nested),
    )
    asyncio.run(review_product(
        product.id, approve=True, db=db,
        current_user=SimpleNamespace(role="admin"),
    ))
    assert product.review_status == "approved"
    assert db.commit.await_count == 2
    assert db.flush.await_count == 1
    # Jedna decyzja Product i dokładnie jeden StoreProduct — wcześniej
    # kod dopisywał ten sam produkt sklepu ponownie poza savepointem.
    assert db.add.call_count == 2
