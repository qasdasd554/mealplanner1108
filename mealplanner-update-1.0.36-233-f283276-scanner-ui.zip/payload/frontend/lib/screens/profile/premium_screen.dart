import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'dart:io' show Platform;
import 'package:flutter_animate/flutter_animate.dart';
import 'package:provider/provider.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:async';
import '../../theme/app_theme.dart';
import '../../providers/auth_provider.dart';
import '../../services/billing_service.dart';
import '../../services/api_client.dart';
import '../../utils/error_utils.dart';
import '../../widgets/campaign_icon.dart';
import '../recipes/recipes_screen.dart';
import '../recipes/ai_add_recipe_screen.dart';
import '../recipes/ingredient_match_select_screen.dart';
import '../recipes/pantry_screen.dart';
import '../batch_barcode_scanner_screen.dart';

/// Ekran prezentacji subskrypcji Premium — lista korzyści + przyciski
/// zakupu, w pełni podłączone pod Google Play Billing. Backend (nie ta
/// aplikacja) ostatecznie decyduje, czy nadać dostęp premium — dopiero
/// PO zweryfikowaniu tokenu zakupu bezpośrednio u Google.
class PremiumScreen extends StatefulWidget {
  final bool popAfterSuccess;

  const PremiumScreen({
    super.key,
    this.popAfterSuccess = true,
  });

  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {
  final BillingService _billing = BillingService();
  StreamSubscription<List<PurchaseDetails>>? _purchaseSub;

  bool _isLoadingProducts = true;
  Map<String, ProductDetails> _products = {};
  List<ProductDetails> _allSubscriptionProducts = [];
  Map<String, Map<String, dynamic>> _campaignsFromBackend = {};
  Map<String, Map<String, dynamic>> _activeOffers = {};
  String? _productsError;

  // Osobne od subskrypcji — pakiety punktów to inna kategoria produktów
  // (konsumowalne), ładowane niezależnie.
  Map<String, ProductDetails> _pointsProducts = {};
  bool _isLoadingPointsProducts = true;

  // Podczas przetwarzania zakupu blokujemy przyciski i pokazujemy
  // spinner — zakup przechodzi przez kilka asynchronicznych kroków
  // (Google -> backend -> potwierdzenie), więc to może potrwać kilka
  // sekund.
  bool _isProcessingPurchase = false;
  bool _isRestoring = false;

  @override
  void initState() {
    super.initState();
    _purchaseSub = _billing.purchaseStream.listen(
      _handlePurchaseUpdates,
      onError: (error) {
        if (!mounted) return;
        setState(() => _isProcessingPurchase = false);
        ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
          const SnackBar(
            duration: Duration(seconds: 3),content: Text('Wystąpił błąd podczas zakupu.')),
        );
      },
    );
    _loadProducts();
    _loadPointsProducts();
    _loadCampaigns();
  }

  Future<void> _loadCampaigns() async {
    try {
      final response = await ApiClient().get('/purchase-campaigns/active');
      if (!mounted || response is! List) return;
      final offers = <String, Map<String, dynamic>>{};
      for (final raw in response) {
        if (raw is! Map<String, dynamic>) continue;
        final productId = raw['product_id'];
        final percent = raw['discount_percent'];
        if (productId is! String || percent is! int) continue;
        final previous = offers[productId];
        if (previous == null || (previous['discount_percent'] as int) < percent) {
          offers[productId] = raw;
        }
      }
      setState(() => _campaignsFromBackend = offers);
      _refreshAvailableOffers();
    } catch (_) {
      // Brak informacji o kampanii nie może zablokować zwykłych zakupów.
    }
  }

  void _refreshAvailableOffers() {
    if (!mounted) return;
    final selectedProducts = <String, ProductDetails>{};
    final effectiveCampaigns = <String, Map<String, dynamic>>{};
    for (final id in const [kWeeklyProductId, kMonthlyProductId, kYearlyProductId]) {
      final regular = _billing.selectRegularSubscriptionOffer(_allSubscriptionProducts, id);
      if (regular != null) selectedProducts[id] = regular;
      final campaign = _campaignsFromBackend[id];
      if (campaign == null) continue;
      if (Platform.isIOS) {
        effectiveCampaigns[id] = campaign;
        continue;
      }
      final basePlanId = campaign['android_base_plan_id'];
      final offerId = campaign['android_offer_id'];
      if (basePlanId is! String || offerId is! String) continue;
      final offer = _billing.selectAndroidSubscriptionOffer(
        _allSubscriptionProducts,
        productId: id,
        basePlanId: basePlanId,
        offerId: offerId,
      );
      // Nie pokazujemy rabatu, jeśli Google Play nie zwróciło tej oferty
      // jako dostępnej dla bieżącego użytkownika. Chroni to przed ekranem
      // z obietnicą -30%, po którym sklep naliczyłby cenę regularną.
      if (offer != null) {
        selectedProducts[id] = offer;
        effectiveCampaigns[id] = campaign;
      }
    }
    // Pakiety punktów korzystają z czasowej ceny produktu ustawionej w
    // odpowiednim sklepie. Kody ofertowe Apple dotyczą tylko subskrypcji.
    for (final id in const [kPoints10ProductId, kPoints20ProductId, kPoints50ProductId]) {
      final campaign = _campaignsFromBackend[id];
      if (campaign != null) effectiveCampaigns[id] = campaign;
    }
    setState(() {
      _products = selectedProducts;
      _activeOffers = effectiveCampaigns;
    });
  }

  Future<void> _openOffer(String productId) async {
    final url = _activeOffers[productId]?['ios_offer_url'];
    if (url is! String) return;
    final uri = Uri.tryParse(url);
    if (uri == null || uri.scheme != 'https' || uri.host != 'apps.apple.com' ||
        uri.path != '/redeem' || uri.queryParameters['ctx'] != 'offercodes') return;
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Nie udało się otworzyć oferty w App Store.')),
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(friendlyError(e))));
    }
  }

  @override
  void dispose() {
    _purchaseSub?.cancel();
    super.dispose();
  }

  Future<void> _loadProducts() async {
    setState(() {
      _isLoadingProducts = true;
      _productsError = null;
    });
    try {
      final available = await _billing.isAvailable();
      if (!available) {
        if (!mounted) return;
        setState(() {
          _isLoadingProducts = false;
          _productsError = 'Płatności są niedostępne na tym urządzeniu (sprawdź konto Google Play).';
        });
        return;
      }

      final response = await _billing.queryProducts();
      if (!mounted) return;
      setState(() {
        _allSubscriptionProducts = response.productDetails;
        _isLoadingProducts = false;
        if (response.productDetails.isEmpty) {
          _productsError = 'Nie udało się pobrać cen subskrypcji. Spróbuj ponownie za chwilę.';
        }
      });
      _refreshAvailableOffers();
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoadingProducts = false;
        _productsError = friendlyError(e);
      });
    }
  }

  Future<void> _loadPointsProducts() async {
    setState(() => _isLoadingPointsProducts = true);
    try {
      final response = await _billing.queryPointsProducts();
      if (!mounted) return;
      setState(() {
        _pointsProducts = {for (final p in response.productDetails) p.id: p};
        _isLoadingPointsProducts = false;
      });
    } catch (e) {
      // Ciche niepowodzenie — punkty to funkcja dodatkowa, nie krytyczna
      // ścieżka; jeśli się nie uda, sekcja po prostu się nie pokaże,
      // reszta ekranu Premium działa normalnie.
      if (!mounted) return;
      setState(() => _isLoadingPointsProducts = false);
    }
  }

  Future<void> _buyPoints(ProductDetails product) async {
    setState(() => _isProcessingPurchase = true);
    try {
      await _billing.buyPoints(product);
    } catch (e) {
      if (!mounted) return;
      setState(() => _isProcessingPurchase = false);
      ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
            duration: const Duration(seconds: 3),content: Text(friendlyError(e)), backgroundColor: AppTheme.errorColor),
      );
    }
  }

  Future<void> _handlePurchaseUpdates(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      if (purchase.status == PurchaseStatus.pending) {
        if (mounted) setState(() => _isProcessingPurchase = true);
        continue;
      }

      if (purchase.status == PurchaseStatus.error) {
        if (mounted) {
          setState(() {
            _isProcessingPurchase = false;
            _isRestoring = false;
          });
          ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
            SnackBar(
            duration: const Duration(seconds: 3),content: Text('Zakup nie powiódł się: ${purchase.error?.message ?? "nieznany błąd"}')),
          );
        }
        // Błąd zgłoszony przez sam sklep — nie ma czego potwierdzać
        // wobec backendu, ale trzeba domknąć transakcję po stronie
        // Google, jeśli tego wymaga.
        if (purchase.pendingCompletePurchase) {
          await _billing.completePurchase(purchase);
        }
        continue;
      }

      if (purchase.status == PurchaseStatus.canceled) {
        if (mounted) setState(() => _isProcessingPurchase = false);
        continue;
      }

      if (purchase.status == PurchaseStatus.purchased || purchase.status == PurchaseStatus.restored) {
        await _verifyWithBackend(purchase);
      }
    }
  }

  Future<void> _verifyWithBackend(PurchaseDetails purchase) async {
    final wasRestoring = _isRestoring;
    final alreadyHadPremium =
        Provider.of<AuthProvider>(context, listen: false)
                .currentUser
                ?.hasPremiumAccess ??
            false;
    // UWAGA (naprawa — poprawny identyfikator dla iOS): na Androidzie
    // serverVerificationData to prawidłowy token Google. Na iOS to samo
    // pole zawiera dane paragonu w starszym formacie — App Store Server
    // API (patrz backend, apple_app_store.py) wymaga natomiast ID
    // TRANSAKCJI, dostępnego jako purchase.purchaseID (odpowiednik
    // SKPaymentTransaction.transactionIdentifier).
    final purchaseToken = defaultTargetPlatform == TargetPlatform.iOS
        ? (purchase.purchaseID ?? purchase.verificationData.serverVerificationData)
        : purchase.verificationData.serverVerificationData;

    // UWAGA (rozszerzenie): pakiety punktów to INNY rodzaj produktu
    // (konsumowalny, nie subskrypcja) i mają OSOBNĄ ścieżkę weryfikacji
    // na backendzie — rozpoznajemy je po identyfikatorze produktu.
    final isPointsPackage = {kPoints10ProductId, kPoints20ProductId, kPoints50ProductId}
        .contains(purchase.productID);

    if (isPointsPackage) {
      await _verifyPointsWithBackend(purchase, purchaseToken);
      return;
    }

    try {
      final isRestore = purchase.status == PurchaseStatus.restored;
      final result = isRestore
          ? await _billing.restoreOnBackend(purchaseToken: purchaseToken, productId: purchase.productID)
          : await _billing.verifyPurchase(purchaseToken: purchaseToken, productId: purchase.productID);

      // UWAGA: potwierdzamy zakup wobec Google TYLKO po tym, jak backend
      // faktycznie potwierdził go u Google i nadał premium — jeśli
      // backend odrzuci zakup (np. nieprawidłowy token), CELOWO NIE
      // wywołujemy completePurchase, żeby nie "zgubić" transakcji, którą
      // można by ponownie zweryfikować (np. przez "Przywróć zakupy").
      if (purchase.pendingCompletePurchase) {
        await _billing.completePurchase(purchase);
      }

      if (!mounted) return;
      if (result['is_premium'] == true) {
        await Provider.of<AuthProvider>(context, listen: false).loadProfile();
        if (!mounted) return;
        setState(() {
          _isProcessingPurchase = false;
          _isRestoring = false;
        });
        // Strumień sklepu potrafi ponownie przesłać stary zakup po
        // uruchomieniu aplikacji. Nie pokazujemy wtedy fałszywej,
        // ponownej aktywacji. Informacja pozostaje przy zakupie nowym
        // albo ręcznym użyciu przycisku "Przywróć zakupy".
        if (!alreadyHadPremium || wasRestoring) {
          ScaffoldMessenger.of(context)
            ..hideCurrentSnackBar()
            ..showSnackBar(
              SnackBar(
                duration: const Duration(seconds: 3),
                content: Text(alreadyHadPremium
                    ? 'Premium jest aktywne.'
                    : 'Premium aktywowane — dziękujemy!'),
              ),
            );
        }
        // Premium może być osobną trasą albo zakładką ekranu głównego.
        // Zamknięcie zakładki przez pop() usuwało jedyną trasę /home
        // i pozostawiało użytkownika z czarnym ekranem.
        if (!alreadyHadPremium &&
            widget.popAfterSuccess &&
            Navigator.of(context).canPop()) {
          Navigator.of(context).pop();
        }
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isProcessingPurchase = false;
        _isRestoring = false;
      });
      ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
            duration: const Duration(seconds: 3),content: Text('Nie udało się potwierdzić zakupu: ${friendlyError(e)}')),
      );
    }
  }

  /// Weryfikacja zakupu PAKIETU PUNKTÓW — osobna od subskrypcji, bo to
  /// inny endpoint backendu i inny rezultat (saldo punktów, nie status
  /// premium). Zakup KONSUMOWALNY musi zostać potwierdzony (completePurchase)
  /// NIEZALEŻNIE od wyniku weryfikacji backendu, bo Google traktuje
  /// niekonsumowane zakupy jako "wiszące" i po ~3 dniach zwraca pieniądze.
  Future<void> _verifyPointsWithBackend(PurchaseDetails purchase, String purchaseToken) async {
    try {
      final newBalance = await _billing.verifyPointsPurchase(
        purchaseToken: purchaseToken,
        productId: purchase.productID,
      );

      if (purchase.pendingCompletePurchase) {
        await _billing.completePurchase(purchase);
      }

      if (!mounted) return;
      await Provider.of<AuthProvider>(context, listen: false).loadProfile();
      if (!mounted) return;
      setState(() => _isProcessingPurchase = false);
      ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
            duration: const Duration(seconds: 3),content: Text('Dodano punkty! Masz teraz $newBalance punktów.')),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isProcessingPurchase = false);
      ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
            duration: const Duration(seconds: 3),content: Text('Nie udało się potwierdzić zakupu: ${friendlyError(e)}')),
      );
    }
  }

  Future<void> _buy(String productId) async {
    final product = _products[productId];
    if (product == null) return;
    setState(() => _isProcessingPurchase = true);
    try {
      await _billing.buy(product);
      // Wynik (sukces/błąd) przyjdzie asynchronicznie przez purchaseStream
      // — patrz _handlePurchaseUpdates.
    } catch (e) {
      if (!mounted) return;
      setState(() => _isProcessingPurchase = false);
      ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
            duration: const Duration(seconds: 3),content: Text('Nie udało się rozpocząć zakupu: ${friendlyError(e)}')),
      );
    }
  }

  Future<void> _useSubscriptionOffer(String productId) async {
    if (Platform.isIOS && _activeOffers.containsKey(productId)) {
      await _openOffer(productId);
      return;
    }
    await _buy(productId);
  }

  Future<void> _usePointsOffer(ProductDetails product) async {
    await _buyPoints(product);
  }

  Future<void> _restore() async {
    setState(() => _isRestoring = true);
    try {
      await _billing.restorePurchases();
      // Jeśli coś się znajdzie, przyjdzie przez purchaseStream jako
      // PurchaseStatus.restored — patrz _handlePurchaseUpdates.
      // Dajemy chwilę na dotarcie zdarzenia, zanim uznamy, że nic nie ma.
      await Future.delayed(const Duration(seconds: 2));
      if (!mounted) return;
      if (_isRestoring) {
        setState(() => _isRestoring = false);
        ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
          const SnackBar(
            duration: Duration(seconds: 3),content: Text('Nie znaleziono żadnych wcześniejszych zakupów do przywrócenia.')),
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _isRestoring = false);
      ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
            duration: const Duration(seconds: 3),content: Text(friendlyError(e))),
      );
    }
  }


  /// Karta bezpośredniej akcji Premium — dotknięcie prowadzi PROSTO do
  /// danej funkcji (nie tylko jej opisuje). Dla kont bez Premium mała
  /// plakietka kłódki sygnalizuje, że dotknięcie skończy się zachętą do
  /// zakupu wewnątrz docelowego ekranu (te ekrany już mają wbudowaną
  /// bramkę Premium z wcześniejszych sesji).
  Widget _buildQuickAction(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required bool isPremium,
    required VoidCallback onTap,
    // UWAGA (naprawa widoczności — punkty premium): dotąd zablokowana
    // pozycja pokazywała TYLKO kłódkę, sugerującą "wymaga Premium", bez
    // żadnej wzmianki, że dla TEJ konkretnej funkcji (AI) istnieje też
    // alternatywna ścieżka za punkty. Stąd wrażenie, że możliwości
    // wymiany punktów na zapytanie w ogóle nie ma — mimo że backend już
    // ją obsługuje (patrz ai_import_recipe). Ten parametr, gdy podany,
    // pokazuje monetę zamiast/obok kłódki i cenę punktową w podtytule.
    int? pointsAlternativeCost,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppTheme.surfaceColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppTheme.secondaryColor.withOpacity(0.15)),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppTheme.secondaryColor.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: AppTheme.secondaryColor, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          title,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                          maxLines: 2,
                          softWrap: true,
                          overflow: TextOverflow.fade,
                        ),
                      ),
                      if (!isPremium && pointsAlternativeCost == null) ...[
                        const SizedBox(width: 6),
                        Icon(Icons.lock_outline, size: 13, color: AppTheme.textSecondary.withOpacity(0.6)),
                      ],
                      if (!isPremium && pointsAlternativeCost != null) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppTheme.accentColor.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.toll, size: 11, color: AppTheme.accentColor),
                              const SizedBox(width: 2),
                              Text(
                                '$pointsAlternativeCost',
                                style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: AppTheme.accentColor),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    !isPremium && pointsAlternativeCost != null
                        ? '$subtitle — albo $pointsAlternativeCost pkt bez subskrypcji'
                        : subtitle,
                    style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: AppTheme.textSecondary.withOpacity(0.5)),
          ],
        ),
      ),
    );
  }

  static const List<_PremiumFeature> _features = [
    _PremiumFeature(
      icon: Icons.qr_code_2,
      title: 'Skanowanie seryjne',
      description: 'Dodawaj wiele produktów do spiżarni bez zamykania aparatu.',
    ),
    _PremiumFeature(
      icon: Icons.all_inclusive,
      title: 'Plany posiłków bez limitu',
      description: 'Generuj tyle planów, ile chcesz — bez tygodniowego limitu.',
    ),
    _PremiumFeature(
      icon: Icons.auto_awesome,
      title: 'Przepisy rozpoznawane przez AI',
      description: 'Dodawaj własne przepisy z wklejonego tekstu albo zdjęcia.',
    ),
    _PremiumFeature(
      icon: Icons.history,
      title: 'Pełna historia śledzenia',
      description: 'Przeglądaj całą historię kalorii, bez limitu 30 dni wstecz.',
    ),
    _PremiumFeature(
      icon: Icons.calendar_view_week,
      title: 'Listy zakupów bez limitu',
      description: 'Twórz nowe listy zakupów wtedy, kiedy ich potrzebujesz.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    // UWAGA (przebudowa): zakładka Premium ma pokazywać FAKTYCZNE
    // funkcje Premium (bezpośrednie skróty), nie tylko listę/tabelę —
    // tabela porównawcza przeniesiona do Profilu (PremiumComparisonTable).
    final user = Provider.of<AuthProvider>(context).currentUser;
    final isPremium = user?.hasPremiumAccess ?? false;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 220,
            pinned: true,
            iconTheme: const IconThemeData(color: Colors.white),
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF6D28D9), Color(0xFFE0A62E)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.15),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(Icons.workspace_premium, color: Colors.white, size: 40),
                      ).animate().scale(duration: 400.ms, curve: Curves.easeOutBack),
                      const SizedBox(height: 12),
                      const Text(
                        'Meal Planner Premium',
                        style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                      ).animate().fadeIn(delay: 150.ms),
                      const SizedBox(height: 4),
                      Text(
                        'Więcej możliwości dla Twojej kuchni',
                        style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 13),
                      ).animate().fadeIn(delay: 250.ms),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(20),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                // Skróty do FAKTYCZNYCH funkcji Premium — bezpośrednie
                // akcje, nie tylko opis. Dla kont bez Premium dotknięcie
                // prowadzi do tego samego miejsca, gdzie wbudowana
                // bramka Premium (już istniejąca w tych ekranach) sama
                // pokaże zachętę do zakupu we właściwym kontekście.
                _buildQuickAction(
                  context,
                  icon: Icons.auto_awesome,
                  title: 'Dodaj przepis przez AI',
                  subtitle: 'Zdjęcie, tekst albo link — AI zrobi resztę',
                  isPremium: isPremium,
                  pointsAlternativeCost: 2,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const AiAddRecipeScreen()),
                  ),
                ),
                const SizedBox(height: 10),
                _buildQuickAction(
                  context,
                  icon: Icons.qr_code_2,
                  title: 'Skanuj wiele produktów po kolei',
                  subtitle: 'Wybierz spiżarnię, katalog albo śledzenie',
                  isPremium: isPremium,
                  onTap: () async {
                    if (!isPremium) {
                      ScaffoldMessenger.of(context)
                        ..hideCurrentSnackBar()
                        ..showSnackBar(const SnackBar(
                          content: Text(
                            'Aktywuj Premium poniżej, aby użyć skanowania seryjnego.',
                          ),
                        ));
                      return;
                    }
                    final completed = await Navigator.of(context).push<int>(
                      MaterialPageRoute(
                        builder: (_) => const BatchBarcodeScannerScreen(),
                      ),
                    );
                    if (!context.mounted || completed == null || completed == 0) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Obsłużono: $completed produktów.')),
                    );
                  },
                ),
                const SizedBox(height: 10),
                _buildQuickAction(
                  context,
                  icon: Icons.groups,
                  title: 'Publikuj przepisy we wspólnocie',
                  subtitle: 'Podziel się swoimi przepisami z innymi',
                  isPremium: isPremium,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const RecipesScreen(initialMyRecipesOnly: true)),
                  ),
                ),
                const SizedBox(height: 10),
                _buildQuickAction(
                  context,
                  icon: Icons.shopping_cart,
                  title: 'Listy zakupów z przepisów',
                  subtitle: 'Do 5 zapisanych list (standard: 1)',
                  isPremium: isPremium,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const RecipesScreen()),
                  ),
                ),
                const SizedBox(height: 10),
                _buildQuickAction(
                  context,
                  icon: Icons.kitchen_outlined,
                  title: 'Co ugotować z tego, co mam',
                  subtitle: 'Zaznacz składniki w domu, dopasujemy przepisy',
                  isPremium: isPremium,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const IngredientMatchSelectScreen()),
                  ),
                ),
                const SizedBox(height: 10),
                _buildQuickAction(
                  context,
                  icon: Icons.inventory_2_outlined,
                  title: 'Twoja spiżarnia',
                  subtitle: 'Zarządzaj produktami, które masz w domu',
                  // Spiżarnia jest dostępna dla WSZYSTKICH kont, nie tylko
                  // Premium — celowo zawsze bez plakietki kłódki.
                  isPremium: true,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const PantryScreen()),
                  ),
                ),
                const SizedBox(height: 28),
                ..._features.asMap().entries.map((entry) {
                  final index = entry.key;
                  final feature = entry.value;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppTheme.secondaryColor.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Icon(feature.icon, color: AppTheme.secondaryColor, size: 22),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                feature.title,
                                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                feature.description,
                                style: TextStyle(color: AppTheme.textSecondary, fontSize: 13, height: 1.3),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ).animate().fadeIn(delay: (300 + index * 100).ms).slideX(begin: 0.05, end: 0);
                }),
                const SizedBox(height: 12),
                ..._buildPricingSection(context),
                const SizedBox(height: 24),
                ..._buildPointsSection(context),
                const SizedBox(height: 20),
                _buildLegalFooter(context),
                const SizedBox(height: 12),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  /// Wymagane przez Apple Guideline 3.1.2: przy subskrypcjach
  /// auto-odnawialnych trzeba pokazać tytuł, długość i cenę każdej
  /// (już widoczne w kartach wyżej), informację o automatycznym
  /// odnawianiu oraz KLIKALNE linki do regulaminu (EULA) i polityki
  /// prywatności — nie wystarczy sam link do polityki prywatności.
  Widget _buildLegalFooter(BuildContext context) {
    return Column(
      children: [
        Text(
          'Subskrypcje odnawiają się automatycznie, chyba że zostaną '
          'anulowane co najmniej 24 godziny przed końcem bieżącego okresu. '
          'Płatność jest pobierana z konta ${Platform.isIOS ? "App Store" : "Google Play"} '
          'po potwierdzeniu zakupu. Możesz zarządzać subskrypcją albo ją '
          'anulować w ustawieniach swojego konta w sklepie.',
          textAlign: TextAlign.center,
          style: TextStyle(color: AppTheme.textSecondary, fontSize: 11, height: 1.4),
        ),
        const SizedBox(height: 8),
        Wrap(
          alignment: WrapAlignment.center,
          children: [
            TextButton(
              onPressed: () => _openLegalUrl(
                context,
                'https://qasdasd554.github.io/mealplanner1108/terms-of-use.html',
              ),
              child: const Text('Regulamin (EULA)', style: TextStyle(fontSize: 12)),
            ),
            TextButton(
              onPressed: () => _openLegalUrl(
                context,
                'https://qasdasd554.github.io/mealplanner1108/privacy-policy.html',
              ),
              child: const Text('Polityka prywatności', style: TextStyle(fontSize: 12)),
            ),
          ],
        ),
      ],
    );
  }

  Future<void> _openLegalUrl(BuildContext context, String url) async {
    // NIE sprawdzamy najpierw canLaunchUrl. Ta metoda potrafi zwrócić
    // false mimo w pełni sprawnej przeglądarki — na Androidzie zależy od
    // deklaracji <queries> w manifeście, a na iOS bywa zawodna przy
    // niektórych konfiguracjach. Wcześniej blokowała otwarcie regulaminu
    // i polityki prywatności, pokazując błąd zamiast strony.
    // Po prostu próbujemy otworzyć i reagujemy dopiero na faktyczny błąd.
    final uri = Uri.parse(url);
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened && context.mounted) {
        // Zapas: część urządzeń nie potrafi otworzyć w przeglądarce
        // zewnętrznej, ale poradzi sobie z widokiem wbudowanym.
        await launchUrl(uri, mode: LaunchMode.inAppBrowserView);
      }
    } catch (_) {
      if (context.mounted) {
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(
            SnackBar(
            duration: const Duration(seconds: 3),content: Text('Nie udało się otworzyć strony: $url')),
          );
      }
    }
  }

  /// Buduje sekcję cennika: status "już masz Premium", stan ładowania,
  /// błąd, albo dwie karty z PRAWDZIWYMI, lokalnymi cenami ze sklepu.
  List<Widget> _buildPricingSection(BuildContext context) {
    final user = Provider.of<AuthProvider>(context).currentUser;
    if (user?.hasPremiumAccess ?? false) {
      final daysLeft = user!.premiumDaysRemaining;
      return [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: AppTheme.primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppTheme.primaryColor.withOpacity(0.3)),
          ),
          child: Row(
            children: [
              const Icon(Icons.check_circle, color: AppTheme.primaryColor, size: 28),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Masz już aktywne Premium', style: TextStyle(fontWeight: FontWeight.bold)),
                    if (daysLeft != null) ...[
                      const SizedBox(height: 2),
                      Text(
                        daysLeft == 0 ? 'Wygasa dziś' : 'Aktywne jeszcze przez $daysLeft ${daysLeft == 1 ? "dzień" : "dni"}',
                        style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ).animate().fadeIn(delay: 700.ms),
      ];
    }

    if (_isLoadingProducts) {
      return const [
        Padding(
          padding: EdgeInsets.symmetric(vertical: 24),
          child: Center(child: CircularProgressIndicator()),
        ),
      ];
    }

    if (_productsError != null) {
      return [
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 16),
          child: Column(
            children: [
              Text(_productsError!, textAlign: TextAlign.center, style: TextStyle(color: AppTheme.errorColor)),
              const SizedBox(height: 8),
              TextButton(onPressed: _loadProducts, child: const Text('Spróbuj ponownie')),
            ],
          ),
        ),
      ];
    }

    final weekly = _products[kWeeklyProductId];
    final monthly = _products[kMonthlyProductId];
    final yearly = _products[kYearlyProductId];

    return [
      if (weekly != null)
        _buildPricingCard(
          context: context,
          title: 'Tygodniowo',
          price: weekly.price,
          period: '',
          highlight: false,
          discountPercent: _activeOffers[kWeeklyProductId]?['discount_percent'] as int?,
          onTap: _isProcessingPurchase ? null : () => _useSubscriptionOffer(kWeeklyProductId),
        ).animate().fadeIn(delay: 650.ms),
      if (weekly != null) const SizedBox(height: 12),
      if (monthly != null)
        _buildPricingCard(
          context: context,
          title: 'Miesięcznie',
          price: monthly.price,
          period: '',
          highlight: false,
          discountPercent: _activeOffers[kMonthlyProductId]?['discount_percent'] as int?,
          onTap: _isProcessingPurchase ? null : () => _useSubscriptionOffer(kMonthlyProductId),
        ).animate().fadeIn(delay: 700.ms),
      if (monthly != null) const SizedBox(height: 12),
      if (yearly != null)
        _buildPricingCard(
          context: context,
          title: 'Rocznie',
          price: yearly.price,
          period: '',
          badge: _activeOffers.containsKey(kYearlyProductId) ? null : 'Oszczędzasz 17%',
          highlight: true,
          discountPercent: _activeOffers[kYearlyProductId]?['discount_percent'] as int?,
          onTap: _isProcessingPurchase ? null : () => _useSubscriptionOffer(kYearlyProductId),
        ).animate().fadeIn(delay: 800.ms),
      const SizedBox(height: 20),
      Text(
        Platform.isIOS
            ? 'Subskrypcję można anulować w ustawieniach Apple ID. Cenę po rabacie potwierdza App Store przed zakupem.'
            : 'Subskrypcję można anulować w dowolnym momencie w ustawieniach Google Play.',
        textAlign: TextAlign.center,
        style: TextStyle(color: AppTheme.textSecondary, fontSize: 11),
      ),
      const SizedBox(height: 12),
      Center(
        child: TextButton.icon(
          onPressed: _isRestoring ? null : _restore,
          icon: _isRestoring
              ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.restore, size: 16),
          label: const Text('Przywróć zakupy'),
        ),
      ),
    ];
  }

  /// Sekcja zakupu pakietów punktów premium — osobna od subskrypcji
  /// (patrz komentarz w _verifyWithBackend): 2 punkty = jedno zapytanie
  /// do AI, dla kont, które nie chcą pełnej subskrypcji, ale chcą
  /// jednorazowo skorzystać z rozpoznawania przepisu przez AI.
  List<Widget> _buildPointsSection(BuildContext context) {
    final auth = Provider.of<AuthProvider>(context);
    final currentBalance = auth.currentUser?.premiumPoints ?? 0;

    return [
      Row(
        children: [
          Icon(Icons.toll_outlined, color: AppTheme.accentColor, size: 20),
          const SizedBox(width: 8),
          Text(
            'Punkty premium',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
          ),
          const Spacer(),
          Text(
            'Masz: $currentBalance',
            style: TextStyle(color: AppTheme.accentColor, fontWeight: FontWeight.bold),
          ),
        ],
      ),
      const SizedBox(height: 4),
      Text(
        '2 punkty = jedno zapytanie do AI (przepis z tekstu, zdjęcia albo linku) — bez subskrypcji.',
        style: TextStyle(color: AppTheme.textSecondary, fontSize: 12),
      ),
      const SizedBox(height: 12),
      if (_isLoadingPointsProducts)
        const Center(child: CircularProgressIndicator())
      else if (_pointsProducts.isEmpty)
        Text(
          'Nie udało się pobrać cen pakietów punktów.',
          style: TextStyle(color: AppTheme.textSecondary),
        )
      else
        Row(
          children: [
            if (_pointsProducts[kPoints10ProductId] != null)
              Expanded(
                child: _buildPointsCard(
                  points: 10,
                  price: _pointsProducts[kPoints10ProductId]!.price,
                  discountPercent: _activeOffers[kPoints10ProductId]?['discount_percent'] as int?,
                  onTap: _isProcessingPurchase
                      ? null
                      : () => _activeOffers.containsKey(kPoints10ProductId)
                          ? _usePointsOffer(_pointsProducts[kPoints10ProductId]!) : _buyPoints(_pointsProducts[kPoints10ProductId]!),
                ),
              ),
            if (_pointsProducts[kPoints20ProductId] != null) ...[
              const SizedBox(width: 8),
              Expanded(
                child: _buildPointsCard(
                  points: 20,
                  price: _pointsProducts[kPoints20ProductId]!.price,
                  discountPercent: _activeOffers[kPoints20ProductId]?['discount_percent'] as int?,
                  onTap: _isProcessingPurchase
                      ? null
                      : () => _activeOffers.containsKey(kPoints20ProductId)
                          ? _usePointsOffer(_pointsProducts[kPoints20ProductId]!) : _buyPoints(_pointsProducts[kPoints20ProductId]!),
                ),
              ),
            ],
            if (_pointsProducts[kPoints50ProductId] != null) ...[
              const SizedBox(width: 8),
              Expanded(
                child: _buildPointsCard(
                  points: 50,
                  price: _pointsProducts[kPoints50ProductId]!.price,
                  discountPercent: _activeOffers[kPoints50ProductId]?['discount_percent'] as int?,
                  highlight: true,
                  onTap: _isProcessingPurchase
                      ? null
                      : () => _activeOffers.containsKey(kPoints50ProductId)
                          ? _usePointsOffer(_pointsProducts[kPoints50ProductId]!) : _buyPoints(_pointsProducts[kPoints50ProductId]!),
                ),
              ),
            ],
          ],
        ),
    ];
  }

  Widget _buildPointsCard({
    required int points,
    required String price,
    required VoidCallback? onTap,
    int? discountPercent,
    bool highlight = false,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
        decoration: BoxDecoration(
          color: highlight ? AppTheme.accentColor.withOpacity(0.12) : AppTheme.surfaceColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: highlight ? AppTheme.accentColor : AppTheme.textSecondary.withOpacity(0.2),
            width: highlight ? 1.5 : 1,
          ),
        ),
        child: Column(
          children: [
            CampaignIcon(icon: Icons.toll, color: AppTheme.accentColor, discountPercent: discountPercent),
            const SizedBox(height: 6),
            Text('$points pkt', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 2),
            Text(discountPercent == null ? price : 'Cena promocyjna: $price',
                textAlign: TextAlign.center, style: TextStyle(color: AppTheme.textSecondary, fontSize: 12)),
            if (discountPercent != null)
              Text(Platform.isIOS ? 'Kup w App Store' : 'Kup w Google Play',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Color(0xFF9F1749), fontSize: 10, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }

  Widget _buildPricingCard({
    required BuildContext context,
    required String title,
    required String price,
    required String period,
    String? badge,
    int? discountPercent,
    required bool highlight,
    required VoidCallback? onTap,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: highlight
            ? const LinearGradient(
                colors: [Color(0xFFF5C24D), Color(0xFFE0A62E)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              )
            : null,
        color: highlight ? null : AppTheme.surfaceColor,
        border: highlight ? null : Border.all(color: AppTheme.textSecondary.withOpacity(0.15)),
        boxShadow: highlight
            ? [
                BoxShadow(
                  color: const Color(0xFFE0A62E).withOpacity(0.35),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ]
            : null,
      ),
      child: Column(
        children: [
          if (badge != null)
            Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.25),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(
                badge,
                style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold),
              ),
            ),
          if (discountPercent != null)
            Align(
              alignment: Alignment.centerLeft,
              child: CampaignIcon(
                icon: Icons.workspace_premium,
                color: highlight ? Colors.white : AppTheme.accentColor,
                discountPercent: discountPercent,
              ),
            ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                      color: highlight ? Colors.white : null,
                    ),
                  ),
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                           text: discountPercent == null
                               ? price
                               : Platform.isIOS ? 'Cena przed kodem: $price' : 'Cena promocyjna: $price',
                          style: TextStyle(
                            fontSize: discountPercent == null ? 22 : 15,
                            fontWeight: FontWeight.bold,
                            color: highlight ? Colors.white : AppTheme.primaryColor,
                          ),
                        ),
                        if (period.isNotEmpty)
                          TextSpan(
                            text: ' $period',
                            style: TextStyle(
                              fontSize: 13,
                              color: highlight ? Colors.white.withOpacity(0.85) : AppTheme.textSecondary,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              )),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: onTap,
                style: highlight
                    ? ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: const Color(0xFFE0A62E),
                        minimumSize: const Size(100, 44),
                      )
                    : ElevatedButton.styleFrom(minimumSize: const Size(100, 44)),
                child: _isProcessingPurchase
                    ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                     : Text(discountPercent == null
                         ? 'Kup Premium'
                         : Platform.isIOS ? 'Odbierz kod' : 'Kup z rabatem'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PremiumFeature {
  final IconData icon;
  final String title;
  final String description;

  const _PremiumFeature({required this.icon, required this.title, required this.description});
}
